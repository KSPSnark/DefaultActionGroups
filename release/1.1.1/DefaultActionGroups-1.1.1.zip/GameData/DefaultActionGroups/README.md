# DefaultActionGroups
KSP mod for setting default action groups for parts (e.g. cockpit lights in Light group)
